# NASCON Event Management System

## Project Overview

NASCON (National Software Competition) Event Management System is a comprehensive web application built with Node.js, Express.js, and MySQL. The system manages events, registrations, judging, sponsorships, and more for the NASCON competition.

## Prerequisites (Detailed for Non-Developers)

Before running this project, make sure you have the following installed on your system:

1.  **Node.js** (v14.0.0 or higher)
    * Go to the Node.js website: https://nodejs.org/
    * Download the LTS (Long Term Support) version for your operating system (Windows, macOS, or Linux).
    * Run the installer and follow the on-screen instructions. Usually, you can accept the default settings.
    * **Verify Installation:**
        * Open a terminal or command prompt.
        * Type `node -v` and press Enter. You should see the version number of Node.js.
        * Type `npm -v` and press Enter. You should see the version number of npm (Node.js package manager).

2.  **MySQL** (v8.0 or higher)
    * Go to the MySQL Community Downloads page: https://dev.mysql.com/downloads/
    * Download the MySQL Installer for your operating system.
    * Run the installer. Pay close attention to the installation options.
        * Make sure to set a strong password for the MySQL root user. You'll need this later.
        * You can usually accept the default settings for most other options.
    * **Verify Installation (Windows):**
        * Open a command prompt.
        * Type `mysql --version` and press Enter. You should see the MySQL version.
    * **Verify Installation (macOS/Linux):**
        * Open a terminal.
        * Type `mysql --version` and press Enter.

3.  **Git** (Optional but Recommended)
    * Git is a version control system. It helps track changes to the project's code.
    * Go to the Git website: https://git-scm.com/
    * Download and install Git for your operating system.
    * **Verify Installation:**
        * Open a terminal or command prompt.
        * Type `git --version` and press Enter.

## Project Setup (Detailed for Non-Developers)

### 1.  Getting the Project Code

    * You'll need to get the project files onto your computer. There are two main ways:
        * **Download as ZIP:** If you received the project as a ZIP file, extract (unzip) it to a folder on your computer.
        * **Clone with Git:**
            * Open a terminal or command prompt.
            * Navigate to the directory where you want to save the project using the `cd` command. For example, `cd Documents/Projects`.
            * If you know the Git repository URL, type `git clone the_repository_url` and press Enter. This will download the project.

### 2.  Setting Up the Database

    * **Open MySQL Command Line or Workbench:**
        * **MySQL Command Line:**
            * Open a terminal or command prompt.
            * Type `mysql -u root -p` and press Enter.
            * You'll be prompted for the MySQL root user password you set during installation.
        * **MySQL Workbench:**
            * Open the MySQL Workbench application.
            * Connect to your local MySQL server using the root user and password.

    * **Create the Database:**
        * In the MySQL command line or a Workbench query tab, type:
            ```sql
            CREATE DATABASE NASCON;
            ```
            and press Enter.
        * Then, type:
            ```sql
            USE NASCON;
            ```
            and press Enter.

    * **Import the Database Schema:**
        * This step creates the tables and structure of the database.
        * **MySQL Command Line:**
            * Make sure you are still in the MySQL command line and the `NASCON` database is selected (you should see `mysql> NASCON` or similar).
            * Navigate in your terminal/command prompt to the directory where the `NASCON.sql` file is located. For example, if it's in `Documents/Projects/nascon`, type `cd Documents/Projects/nascon`.
            * Then, type:
                ```bash
                mysql -u root -p NASCON < NASCON.sql
                ```
                and press Enter. You'll be prompted for the MySQL root password.
        * **MySQL Workbench:**
            * In Workbench, go to `File` -> `Open SQL Script...` and select the `NASCON.sql` file.
            * Click the "Execute" button (usually a lightning bolt icon) to run the script. Make sure you're connected to the `NASCON` database.

### 3.  Installing Project Dependencies

    * **Open Terminal/Command Prompt:**
        * Navigate to the main project directory (the one containing the `package.json` file) using the `cd` command.

    * **Install Dependencies:**
        * Type:
            ```bash
            npm install
            ```
            and press Enter. This command tells npm to download and install all the necessary Node.js packages (like Express.js) listed in the `package.json` file.

### 4.  Configuring Environment Variables

    * **Create a `.env` File:**
        * In the main project directory, create a new file named `.env` (no filename, just an extension).
        * Open this file in a text editor (like Notepad on Windows, TextEdit on macOS, or VS Code).

    * **Add Configuration Details:**
        * Copy and paste the following content into the `.env` file, and replace the placeholders with your actual information:

            ```env
            PORT=3000 # The port the application will run on (you can usually leave this as 3000)
            DB_HOST=localhost # The address of your MySQL server (usually 'localhost' if it's on your computer)
            DB_USER=your_mysql_username # Your MySQL username (e.g., 'root')
            DB_PASSWORD=your_mysql_password # The MySQL password you set during installation
            DB_NAME=NASCON # The name of the MySQL database you created
            SESSION_SECRET=your_secret_key #  A secret key used to secure user sessions.  
                                          #  Choose a long, random string (e.g., 'asdfjkl12345!@#')
            ```
        * **Important:** The `SESSION_SECRET` is crucial for security. Don't use a simple or obvious value.

    * **Save the `.env` File.**

### 5.  Running the Application

    * **Open Terminal/Command Prompt:**
        * Navigate to the main project directory.

    * **Start the Server:**
        * Type:
            ```bash
            npm start
            ```
            and press Enter.
        * You should see a message like "Server is running on port 3000".

    * **Open in Browser:**
        * Open your web browser (e.g., Chrome, Firefox, Safari).
        * Type `http://localhost:3000` in the address bar and press Enter.
        * You should now see the NASCON Event Management System's homepage.

## Project Structure

### Main Directories

* `src/` - Contains all source code
    * `config/` - Configuration files
    * `middleware/` - Express middleware
    * `public/` - Static files (CSS, JavaScript, images)
    * `routes/` - Route handlers
    * `views/` - EJS templates
    * `utils/` - Utility functions

### Key Files Explanation

#### Configuration Files

* `src/config/database.js` - Database connection configuration
* `src/app.js` - Main application setup
* `NASCON.sql` - Complete database schema

#### Route Handlers

1.  `src/routes/auth.js`
    * Handles user authentication
    * Login/logout functionality
    * User role management

2.  `src/routes/events.js`
    * Event management (CRUD operations)
    * Event details and listings
    * Event registration handling

3.  `src/routes/judges.js`
    * Judge management
    * Score submission
    * Judge assignments

4.  `src/routes/sponsors.js`
    * Sponsor management
    * Sponsorship packages
    * Sponsor profiles

5.  `src/routes/registration.js`
    * Event registration
    * Team registration
    * Registration confirmation

6.  `src/routes/payments.js`
    * Payment processing
    * Payment verification
    * Financial reports

#### View Templates

1.  `src/views/partials/`
    * Header, footer, and navigation components
    * Reusable UI elements

2.  `src/views/events/`
    * Event listing pages
    * Event detail pages
    * Event registration forms

3.  `src/views/judges/`
    * Judge dashboard
    * Scoring interface
    * Judge management

4.  `src/views/sponsors/`
    * Sponsor listing
    * Sponsorship packages
    * Sponsor registration

## Detailed File Functionality

### 1. Configuration Files

* **`src/config/database.js`**

    * **Purpose:** This file is responsible for connecting the Node.js application to the MySQL database.
    * **Key Functionality:**
        * It uses the `mysql2` library to establish a connection pool. A connection pool is a set of database connections that can be reused, which improves performance.
        * It reads database connection details (host, user, password, database name) from the `.env` file.
        * It includes a function (`initializeDatabase`) that:
            * Tests the database connection.
            * Creates the `NASCON` database if it doesn't already exist.
            * Executes a simple query to verify that the database is working correctly.
        * It provides helper functions:
            * `executeQuery`: Executes SQL queries and returns the results. It includes error handling to catch common database issues.
            * `executeTransaction`: Executes multiple SQL queries as a single transaction (either all queries succeed, or none of them do), ensuring data consistency.

* **`src/config/passport.js`**

    * **Purpose:** Configures Passport.js for user authentication.
    * **Key Functionality:**
        * `passport.serializeUser`: Determines what data from the user object is stored in the session (usually the user ID). This is efficient because we don't have to store the entire user object in the session.
        * `passport.deserializeUser`: Retrieves the user's information from the database based on the user ID stored in the session. This allows us to access the user's data throughout the application.

### 2. Middleware Files

* **`src/middleware/auth.js`**

    * **Purpose:** Contains middleware functions for authorization (checking user permissions).
    * **Key Functionality:**
        * `isAuthenticated`: Checks if the user is logged in. If not, it returns an "Unauthorized" error.
        * `isJudge`: Checks if the user is a judge.
        * `hasPrivilege(resource, action)`: A flexible middleware that checks if the user has a specific privilege (e.g., "events", "create"). Privileges are defined in the database.
        * `isAdmin`: Checks if the user has the "admin" role.

* **`src/middleware/notification.js`**

    * **Purpose:** Manages displaying notifications (success, error, etc.) to the user.
    * **Key Functionality:**
        * `notification`: Middleware that makes the current notification (if any) available to the view templates and then clears the notification from the session.
        * `setNotification(req, message, type)`: A helper function to create and store a notification in the user's session.

* **`src/middleware/validation.js`**

    * **Purpose:** Uses the `express-validator` library to validate data from user input (e.g., registration form, event creation form).
    * **Key Functionality:**
        * `validate`: A middleware function that checks for validation errors and returns a 400 error with the error details if any are found.
        * `registerValidation`: An array of validation rules specifically for the user registration form (e.g., checking password strength, email format).
        * `eventValidation`: An array of validation rules for the event creation/update form (e.g., checking date formats, required fields).

* **`src/middleware/venueValidation.js`**

    * **Purpose:** Uses the `express-validator` library to validate venue data.
    * **Key Functionality:**
        * `validate`: A middleware function that checks for validation errors and returns a 400 error with the error details if any are found.
        * `venueValidation`: An array of validation rules for the venue creation/update form.

### 3. Route Files

* **`src/routes/about.js`**

    * **Purpose:** Handles requests for the "About Us" page.
    * **Key Functionality:**
        * Defines a route (`/about`) that renders the `about.ejs` template.

* **`src/routes/accommodations.js`**

    * **Purpose:** Manages accommodation and venue-related functionality.
    * **Key Functionality:**
        * Retrieves and displays lists of accommodations and venues.
        * Handles requests to create accommodation requests.
        * Provides API endpoints to get accommodation requests and generate reports.
        * Handles adding new accommodations (including file uploads for photos).

* **`src/routes/auth.js`**

    * **Purpose:** Handles user authentication and authorization.
    * **Key Functionality:**
        * `logout`: Logs the user out.
        * `current-user`: Provides details about the currently logged-in user.
        * `is-admin`: Checks if the current user is an administrator.
        * `users/:email`: Retrieves user details by email (requires authentication and privileges).
        * `users`: Retrieves a list of all users (admin only).

* **`src/routes/categories.js`**

    * **Purpose:** Manages event categories.
    * **Key Functionality:**
        * Retrieves and displays a list of event categories.
        * Handles adding, editing, and deleting categories (requires authentication and privileges).
        * Provides an API endpoint to get all categories.

* **`src/routes/competitions.js`**

    * **Purpose:** Handles competition-related functionality.
    * **Key Functionality:**
        * Retrieves and displays a list of competitions.
        * Provides API endpoints to get competitions and categories.
        * Handles registration for competitions.

* **`src/routes/contact.js`**

    * **Purpose:** Manages the contact form.
    * **Key Functionality:**
        * Displays the contact page.
        * Handles the submission of contact form inquiries and saves them to the database.

* **`src/routes/events.js`**

    * **Purpose:** Handles the creation, display, and management of events.
    * **Key Functionality:**
        * Retrieves and displays a list of events.
        * Handles adding, editing, and deleting events (requires authentication and privileges).
        * Provides an API to get event details.

* **`src/routes/faq.js`**

    * **Purpose:** Handles the FAQ pages.
    * **Key Functionality:**
        * Defines routes for different FAQ sections (registration, fees, refund policy).

* **`src/routes/index.js`**

    * **Purpose:** Handles the main homepage.
    * **Key Functionality:**
        * Retrieves and displays upcoming events on the homepage.

* **`src/routes/judges.js`**

    * **Purpose:** Manages judges and their assignments to events.
    * **Key Functionality:**
        * Retrieves and displays a list of judges.
        * Handles adding, editing, and deleting judges (requires authentication and privileges).
        * Handles assigning judges to events.

* **`src/routes/login.js`**

    * **Purpose:** Handles user login.
    * **Key Functionality:**
        * Displays the login page.
        * Processes user login attempts, verifies credentials, and creates user sessions.

* **`src/routes/payments.js`**

    * **Purpose:** Manages payment processing.
    * **Key Functionality:**
        * Handles registration payments.
        * Records sponsorship payments.
        * Generates payment reports.
        * Provides APIs to get events and sponsors for payment forms.

* **`src/routes/registration.js`**

    * **Purpose:** Handles user registration.
    * **Key Functionality:**
        * Displays the user registration page.
        * Processes new user registrations, including password hashing.
        * Handles event registrations.

* **`src/routes/schedule.js`**

    * **Purpose:** Displays the event schedule.
    * **Key Functionality:**
        * Retrieves and displays a list of events, grouped by date.
        * Provides an API to get events with filtering options.

* **`src/routes/scores.js`**

    * **Purpose:** Manages the submission and retrieval of scores for events.
    * **Key Functionality:**
        * Retrieves scores for a specific event or participant.
        * Handles submitting new scores.
        * Handles updating and deleting scores (requires judge authentication).

* **`src/routes/sponsors.js`**

    * **Purpose:** Manages sponsor information and sponsorship packages.
    * **Key Functionality:**
        * Retrieves and displays a list of sponsors.
        * Handles adding, editing, and deleting sponsors (requires authentication).
        * Manages sponsorship contracts and payments.

* **`src/routes/teams.js`**

    * **Purpose:** Manages teams participating in events.
    * **Key Functionality:**
        * Retrieves and displays a list of teams.
        * Handles creating teams.
        * Manages team members (adding, removing, updating).

* **`src/routes/venues.js`**

    * **Purpose:** Manages venue information.
    * **Key Functionality:**
        * Retrieves and displays a list of venues.
        * Handles adding, editing, and deleting venues (requires authentication and privileges).
        * Provides an API to get venue details.

* **`src/routes/workshops.js`**

    * **Purpose:** Manages workshops and guest speakers.
    * **Key Functionality:**
        * Retrieves and displays lists of workshops and speakers.

### 4. Public Files

* **`src/public/css/`:** Contains CSS files that control the styling of the web pages. Each CSS file is typically associated with a specific page or section of the site.
* **`src/public/js/`:** Contains JavaScript files that add interactivity to the web pages.
    * `competitions.js` (src/public/js/competitions.js): JavaScript for the competitions page.
    * `header.js` (src/public/js/header.js): JavaScript for the header section of the website.
    * `main.js` (src/public/js/main.js): Main JavaScript file with general site functionality.

### 5. Other Important Files

* **`src/app.js`**

    * **Purpose:** This is the entry point of the Node.js application. It sets up the Express.js web server.
    * **Key Functionality:**
        * Imports all the necessary libraries and route files.
        * Configures middleware (e.g., for handling JSON data, sessions, security).
        * Defines the routes of the application (which URLs are handled by which route files).
        * Sets up the view engine (EJS) to render HTML pages.
        * Handles errors and 404 (page not found) scenarios.
        * Starts the server and listens for incoming requests.

* **`package.json`**

    * **Purpose:** A JSON file that contains metadata about the project and its dependencies.
    * **Key Functionality:**
        * `name`, `version`, `description`, etc.: Basic information about the project.
        * `scripts`: Defines commands that can be run with `npm` (e.g., `npm start` to start the server).
        * `dependencies`: Lists the Node.js packages that the project needs to function. `npm install` uses this list to install the packages.
        * `devDependencies`: Lists packages used for development (e.g., testing tools).

* **`NASCON.sql`**

    * **Purpose:** Contains the SQL code to create the database schema (the tables, columns, and relationships) for the NASCON application.
    * **Key Functionality:**
        * `DROP DATABASE IF EXISTS NASCON; CREATE DATABASE NASCON; USE NASCON;`: Commands to delete the database if it exists and create a new one.
        * `CREATE TABLE ...`: SQL statements to create tables like `Users`, `Events`, `Venues`, etc.
        * `ALTER TABLE ...`: SQL statements to modify table structures, add constraints, etc.
        * `INSERT INTO ...`: SQL statements to insert initial data into some tables (e.g., default user roles).
        * `CREATE VIEW ...`: SQL statements to create database views.
        * `CREATE PROCEDURE ...`: SQL statements to create stored procedures.
        * `CREATE TRIGGER ...`: SQL statements to create database triggers.

## Key Features and Functionality

The NASCON Event Management System provides a range of features to manage the competition effectively:

* **User Management:**
    * Allows users to register for accounts with different roles (admin, event organizer, participant, sponsor, judge).
    * Handles user authentication (login and logout).
    * Implements role-based access control, so different users have different permissions.

* **Event Management:**
    * Enables the creation, editing, and deletion of events.
    * Supports event categorization and different event types.
    * Manages event details like date, time, venue, and registration deadlines.
    * Handles event registration and participant tracking.

* **Judging System:**
    * Facilitates the assignment of judges to events.
    * Provides interfaces for judges to submit scores.
    * Calculates rankings based on scores.
    * Displays results.

* **Sponsorship Management:**
    * Manages sponsor profiles and contact information.
    * Defines different sponsorship packages.
    * Tracks sponsorship payments and benefits.

* **Payment System:**
    * Processes registration fees.
    * Handles sponsorship payments.
    * Provides payment verification and financial reporting.

## Common Issues & Solutions

1.  **Database Connection Error**

    * **Solution:**
        * Double-check that the MySQL server is running.
        * Carefully verify the database credentials (username, password, host, database name) in the `.env` file. Even a small typo will cause a connection error.
        * Ensure that the `NASCON` database has been created in MySQL.

2.  **Port Already in Use**

    * **Solution:**
        * The default port for the application is 3000. If another application is already using this port, you'll get an error.
        * You can change the port in the `.env` file by modifying the `PORT` variable.
        * Alternatively, you can identify and stop the process that's currently using the port. The commands to do this vary depending on your operating system.

3.  **Module Not Found Errors**

    * **Solution:**
        * If you see errors like "Cannot find module 'express'", it means the required Node.js packages haven't been installed.
        * Make sure you have navigated to the project directory in your terminal/command prompt and run `npm install` again.
        * Check the `package.json` file to see the list of dependencies.
        * Ensure that the `node_modules` directory exists in your project directory. This directory is where npm installs the packages.

## Required NPM Packages

```json
{
  "dependencies": {
    "bcrypt": "^5.1.1",
    "cors": "^2.8.5",
    "dotenv": "^16.5.0",
    "ejs": "^3.1.9",
    "express": "^4.18.3",
    "express-session": "^1.18.0",
    "express-validator": "^7.2.1",
    "helmet": "^7.1.0",
    "multer": "^1.4.5-lts.2",
    "mysql2": "^3.14.1",
    "passport": "^0.7.0",
    "passport-facebook": "^3.0.0",
    "passport-google-oauth20": "^2.0.0"
  },
  "devDependencies": {
    "nodemon": "^3.1.10"
  }
}
```

## Contributing
1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

## Support
For any questions or issues:
1. Check the common issues section
2. Review error logs
3. Contact the development team

## License
This project is licensed under the MIT License. 